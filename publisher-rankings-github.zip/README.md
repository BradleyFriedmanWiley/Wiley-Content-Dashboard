# OpenAlex Publisher Rankings Dashboard

Interactive dashboards showing publisher market share across scientific research domains, built on OpenAlex data.

## Live Site

**[View Dashboard →](https://USERNAME.github.io/REPO-NAME/)**

> Replace `USERNAME` and `REPO-NAME` with your GitHub username and repository name after deployment.

## Dashboards

| Dashboard | Topics | Description |
|-----------|--------|-------------|
| [Home](index.html) | — | Landing page with domain overview cards |
| [Health Sciences](domain-health_sciences.html) | 1,105 | Medicine, nursing, dentistry, public health |
| [Life Sciences](domain-life_sciences.html) | 1,240 | Biology, biochemistry, genetics, ecology |
| [Physical Sciences](domain-physical_sciences.html) | 1,390 | Chemistry, physics, engineering, materials |
| [Social Sciences](domain-social_sciences.html) | 781 | Psychology, economics, education, political science |
| [Cross-Domain](domain-cross_domain.html) | 4,516 | All domains combined with domain toggle filters |

## Features

- **Publisher Rankings** — Topic-level and subfield-level market share for top publishers
- **Year Filtering** — All-time view plus 2021–2025 individual years
- **Interactive Charts** — Stacked bar charts, sortable tables, search/filter
- **Fully Standalone** — Each HTML file is self-contained with embedded data
- **No Build Step** — Open any `.html` file directly in a browser

## Setup (GitHub Pages)

1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Set source to **Deploy from a branch** → `main` → `/ (root)`
4. Your site will be live at `https://USERNAME.github.io/REPO-NAME/`

## Data Source

- **OpenAlex** (February 2026 snapshot)
- Publisher normalization maps imprints to parent companies (e.g., Hindawi → Wiley)
- Institution filtering excludes repository hosts
- See [data-pipeline-diagram.html](data-pipeline-diagram.html) for the full pipeline

## Technical Details

- Pure client-side HTML/JS (React 18 + Babel via CDN)
- No server required, no analytics, no tracking
- ~550KB–2.1MB per file (data embedded inline)
- Works in Chrome 90+, Firefox 88+, Safari 14+, Edge 90+

---

**Last updated**: March 2026
