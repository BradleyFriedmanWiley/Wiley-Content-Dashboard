# Standalone Dashboard Files

Self-contained, single-file HTML versions of the R&D Intelligence Dashboard that work without a web server. Each file embeds all data inline and can be opened directly in any modern browser.

## Quick Start

**Open the landing page:**

```bash
# macOS
open index-static.html

# Windows
start index-static.html

# Linux
xdg-open index-static.html
```

Or **open a specific domain directly:**

```bash
# macOS
open domain-health_sciences.html

# Windows
start domain-health_sciences.html

# Linux
xdg-open domain-health_sciences.html
```

Or simply **double-click** any `.html` file in your file manager.

## Available Files

### Landing Page

| File | Purpose | Size |
|------|---------|------|
| `index-static.html` | Landing page with domain cards | 20 KB |

### Domain Dashboards

| File | Domain | Size | Topics | Subfields |
|------|--------|------|--------|-----------|
| `domain-health_sciences.html` | Health Sciences | 671 KB | 1,105 | 164 |
| `domain-life_sciences.html` | Life Sciences | 525 KB | 1,240 | 119 |
| `domain-physical_sciences.html` | Physical Sciences | 781 KB | 1,390 | 127 |
| `domain-social_sciences.html` | Social Sciences | 715 KB | 781 | 102 |

## Features

✅ **No server required** — Works with `file://` protocol  
✅ **Fully self-contained** — All JSON data embedded inline  
✅ **Complete functionality** — Year picker, rankings, charts, all tabs  
✅ **Portable** — Share via email, USB, cloud storage, or intranet  
✅ **Offline-ready** — Works without internet (after initial CDN load)

## Building Standalone Files

To generate or update standalone files:

```bash
# From the repo root
cd visualizations/dashboards

# Build a single domain
uv run python scripts/build_standalone.py --domain health_sciences

# Build all domains
for domain in health_sciences life_sciences physical_sciences social_sciences; do
  uv run python scripts/build_standalone.py --domain $domain
done

# Custom output path
uv run python scripts/build_standalone.py --domain health_sciences --output custom-name.html
```

## What's Included

Each standalone file contains:

- **Dashboard core data** (`dashboard_core.json`)
  - Market sizes, CAGR, therapeutic areas
  - Clinical trial data, pharma companies
  - Use case definitions, competitive landscape
  
- **Domain-specific data** (`domain_<slug>.json`)
  - 4,516 OpenAlex topics with publisher shares
  - Subfield-level aggregations
  - Per-year data (2021–2025)
  - Therapeutic area mappings (Health Sciences only)
  - Open Access percentages

- **Full React dashboard**
  - All tabs: Overview, Topics, Rankings, Analysis, Sources
  - Year filtering (all-time + 2021–2025)
  - Interactive charts and tables
  - Publisher detail views

## Technical Details

### Architecture

```html
<head>
  <!-- React 18 (development build for file:// compatibility) -->
  <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
  <div id="root"></div>
  
  <!-- 1. Embedded data (~500KB, plain JavaScript) -->
  <script>
    var SOURCES = {...};
    var OALEX = {...};
    // ... all domain data
  </script>
  
  <!-- 2. React application (Babel-transpiled) -->
  <script type="text/babel">
    const App = () => { /* dashboard code */ };
  </script>
</body>
```

### Data Pipeline

The standalone files are the final output of a multi-phase data pipeline
that fetches, caches, aggregates, and bundles OpenAlex data.
Open **[data-pipeline-diagram.html](data-pipeline-diagram.html)** in a browser to view the interactive diagram.

**Key processing steps in Phase 5:**
- **Publisher normalization** — Maps imprints to parent publishers (e.g., Hindawi → Wiley)
- **Institution filtering** — Excludes repository hosts; only true publishers counted
- **Wiley rank** — Computes Wiley's rank vs all publishers per topic by work count
- **Subfield aggregation** — Rolls up topics into ~250 subfields with top-5 publishers
- **Yearly breakdowns** — Per-subfield/disease metrics for 2021–2025 (enables year picker)
- **Disease mapping** — Maps 57 therapeutic areas to OpenAlex topics (Health Sciences only)

### Browser Compatibility

- **Chrome/Edge**: ✅ Full support
- **Firefox**: ✅ Full support
- **Safari**: ✅ Full support
- **Mobile browsers**: ✅ Works (may be slow on older devices)

**Minimum versions:**
- Chrome 90+, Firefox 88+, Safari 14+, Edge 90+

### Performance

- **Initial load**: 2–4 seconds (includes CDN script loading)
- **Subsequent loads**: Instant (browser cache)
- **File size**: 550–700 KB (uncompressed)
- **Memory usage**: ~150–200 MB

### Limitations

1. **Requires internet for first load** — React/Babel scripts load from CDN
2. **No server-side features** — Cannot fetch new data or update dynamically
3. **Larger file size** — Compared to server-based version with external JSON
4. **No cross-domain navigation** — Each domain is a separate file

## Differences from Server Version

| Feature | Server Version | Standalone Version |
|---------|---------------|-------------------|
| Requires web server | ✅ Yes | ❌ No |
| Domain switching | ✅ Via dropdown | ❌ Separate files |
| Back to index link | ✅ Yes | ❌ Removed |
| Data loading | 📡 Async fetch | 💾 Inline |
| File size | ~50 KB HTML + JSON | ~650 KB single file |
| Update data | 🔄 Replace JSON | 🔄 Rebuild HTML |

## Updating Data

When the underlying data changes (e.g., new OpenAlex fetch):

1. **Regenerate domain JSON** (if needed):
   ```bash
   uv run python scripts/generate_domain_data.py --domain all --yearly
   ```

2. **Rebuild standalone files**:
   ```bash
   uv run python scripts/build_standalone.py --domain health_sciences
   ```

3. **Distribute updated files** to users

## Distribution

### Complete Package

For the best experience, distribute all 5 files together:
- `index-static.html` (landing page)
- `domain-health_sciences.html`
- `domain-life_sciences.html`
- `domain-physical_sciences.html`
- `domain-social_sciences.html`

**Uncompressed**: ~2.7 MB  
**Compressed (zip)**: 642 KB

A pre-built zip file is available at `visualizations/dashboards-standalone.zip` containing:
- All 5 HTML files
- Documentation (README.md, STANDALONE.md, INSTALL.md)
- Python dependencies file (pyproject.toml)

### Email

For individual domains, attach a single `.html` file (most email clients support <1 MB attachments).

### Cloud Storage

Upload all files to Dropbox, Google Drive, OneDrive, etc. Share the folder link.

### Intranet

Place all files in a shared network drive or internal web server. Users can open `index-static.html` to start.

### USB/Physical Media

Copy all files to USB drive for offline distribution. Users open `index-static.html` first.

## Troubleshooting

### "Blank page" or "Loading forever"

- **Check browser console** (F12) for errors
- **Verify file integrity** — Re-download or rebuild
- **Try a different browser** — Some corporate firewalls block CDN scripts
- **Check internet connection** — Required for first load (CDN scripts)

### "Data not loading" or "SOURCES is not defined"

- **Clear browser cache** and reload
- **Rebuild the file** — May be corrupted or from old build script version

### "Slow performance"

- **Use Chrome/Edge** — Generally fastest for large data
- **Close other tabs** — Frees up memory
- **Upgrade browser** — Older versions may be slower

### "Charts not displaying"

- **Enable JavaScript** — Required for React
- **Check browser compatibility** — Use modern browser (see above)

## Security Notes

- **No server-side code** — Pure client-side HTML/JS
- **No external data sources** — All data embedded
- **CDN dependencies** — React/Babel loaded from unpkg.com (trusted CDN)
- **No analytics or tracking** — Completely private

## Support

For issues or questions:

1. Check this README
2. See main dashboard documentation: `README.md`
3. Review build script: `scripts/build_standalone.py`
4. Contact: Wiley R&D Intelligence Team

---

**Last updated**: March 2026  
**Data source**: OpenAlex (February 2026 snapshot)  
**Dashboard version**: 2.0 (Multi-domain with year filtering)
