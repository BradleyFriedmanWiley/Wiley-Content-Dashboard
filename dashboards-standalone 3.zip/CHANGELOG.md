# Changelog

All notable changes to the Wiley Publisher Content Dashboards.

---

## [2.0.0] — 2026-03-19

### Added
- **Cross-Domain Publishing Dashboard** — aggregates all 4 OpenAlex domains (4,516 topics, 250 subfields, 30 fields) with domain toggle checkboxes
- **Cross-domain keyword search** — search bar on the dashboard with view-aware filtering (fields, subfields, topics) and dynamic publisher card updates
- **Landing page search** — search topics across all domains with prefix syntax (`field:chemistry`, `subfield:oncology`, `topic:alzheimer`); domain cards update dynamically with filtered stats and Wiley market share
- **Fields view** — new tab showing OpenAlex field-level aggregation (26 fields across all domains) replacing "Therapeutic Areas" for non-Health Sciences domains
- **Bubble Scatterplot for all domains** — Visualize tab with total works vs. Wiley share scatter plot for non-Health Sciences domains
- **Data pipeline diagram** — interactive HTML visualization of the 6-phase OpenAlex data pipeline
- **Field-level data** in all domain JSONs (`FIELD_DATA`, `FIELD_PUB_DETAIL`)
- **Cross-domain data generator** (`generate_cross_domain_data.py`)
- **Topic search index** (`topic_search_index.json`) with 4,516 topics including field names

### Changed
- **Top 5 publishers** now displayed across all views (was 2-3); OA_TOPICS extended from 12 to 18 columns with r3-r5 publisher data
- **Dynamic publisher summary cards** — show Wiley + actual top 3 competitors per domain (e.g., IEEE for Physical Sciences) instead of hardcoded Elsevier/Springer/Wolters Kluwer
- **Non-Health Sciences domains** simplified — only Publisher Rankings + Visualize tabs; removed Use Cases, Disease Area Deepdives, Pharma, Strategy, Vendors tabs; Ecosystem Network hidden
- **Landing page redesign** — new design with DM Sans/Serif typography, featured cross-domain card, domain position stats (Wiley #1/#2/Top 2), market share bars
- **Table column alignment** — fixed-width columns (220px names, 260px publishers) for consistent alignment across all table views
- **Subfield sub-row alignment** — expanded topic rows now align with parent table columns
- **Copyright footer** added to Publisher Rankings, Disease Area Deepdives, and Visualize tabs
- **Year range references** removed from descriptions (year picker is dynamic)

### Fixed
- **Search input focus loss** — changed inline Page components from JSX element syntax to function calls to preserve DOM identity across re-renders
- **Visualize tab crash** — fixed "Rendered more hooks than during the previous render" error by keeping VisualizePage as a JSX component
- **Subfield year-filtering** — `effectiveSfData` now computes r3-r5 publishers from year-filtered data instead of carrying stale all-time values

### Data Changes
- **Wiley rank shifts across all domains** due to updated OpenAlex API data (re-fetched March 16, 2026). The v1.0 dashboards were built from a February 5 fetch that counted **all work types** (articles, preprints, book chapters, conference papers). The v2.0 data was re-fetched with stricter filters: `primary_location.source.type:journal` and `is_retracted:false`, counting only **journal articles** and excluding retracted works. This caused total work counts to decrease (e.g., Astronomy: 206K → 172K) while Wiley's absolute counts often increased due to better Hindawi aggregation. Net effect: Physical Sciences went from 130 #1 / 172 #2 to 109 #1 / 76 #2. Wiley's market *share* improved in most topics (e.g., Astronomy: 5.88% → 8.22%) because the removed non-journal works disproportionately belonged to other publishers. This is a data quality improvement — the new numbers more accurately reflect Wiley's position in journal publishing specifically.

---

## [1.0.0] — 2026-03-16

### Initial Release
- 4 domain dashboards: Health Sciences, Life Sciences, Physical Sciences, Social Sciences
- Publisher Rankings with Therapeutic Areas, Subfields, and Topics views
- Year picker (2021-2025) for subfield and disease-level data
- Bubble Scatterplot and Ecosystem Network visualizations (Health Sciences)
- Standalone HTML builds with embedded data (no server required)
- OpenAlex API key support for data fetching
